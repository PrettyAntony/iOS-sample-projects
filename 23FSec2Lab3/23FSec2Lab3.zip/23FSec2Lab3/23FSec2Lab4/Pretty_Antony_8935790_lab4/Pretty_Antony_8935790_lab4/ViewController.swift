//
//  ViewController.swift
//  Pretty_Antony_8935790_lab4
//
//  Created by user234138 on 9/27/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBAction func onTouch(_ sender: UITapGestureRecognizer) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

