import UIKit

import Foundation
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let weatherData = try? JSONDecoder().decode(WeatherData.self, from: jsonData)

import Foundation

// MARK: - WeatherData
struct WeatherData: Codable {
    let coord: Coord
    let weather: [Weather]
    let base: String
    let main: Main
    let visibility: Int
    let wind: Wind
    let clouds: Clouds
    let dt: Int
    let sys: Sys
    let timezone, id: Int
    let name: String
    let cod: Int
}

// MARK: - Clouds
struct Clouds: Codable {
    let all: Int
}

// MARK: - Coord
struct Coord: Codable {
    let lon, lat: Double
}

// MARK: - Main
struct Main: Codable {
    let temp, feelsLike, tempMin, tempMax: Double
    let pressure, humidity: Int

    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure, humidity
    }
}

// MARK: - Sys
struct Sys: Codable {
    let type, id: Int
    let country: String
    let sunrise, sunset: Int
}

// MARK: - Weather
struct Weather: Codable {
    let id: Int
    let main, description, icon: String
}

// MARK: - Wind
struct Wind: Codable {
    let speed: Double
    let deg: Int
}

//Step 1
//API session
//let urlString = "https://api.openweathermap.org/data/2.5/weather?q=Waterloo,ca&appid=19f9d90b57c0bbfe1e5c83549efff66c"

let urlString = "https://api.openweathermap.org/data/2.5/weather?q=Waterloo,ca&appid=19f9d90b57c0bbfe1e5c83549efff66c&units=metric"

// Note this shouls be a VAR in when used in an application as the URL value will change with each call!
// Create an instance of a URLSession Class and assign the value of your URL to the The URL in the Class
let urlSession = URLSession(configuration:.default)
let url = URL(string: urlString)

// Check for Valid URL
if let url = url {
    // Create a variable to capture the data from the URL
    let dataTask = urlSession.dataTask(with: url) { (data, response, error) in
        
        // If URL is good then get the data and decode
        if let data = data {
            print (data)
            let jsonDecoder = JSONDecoder()
            do {
                // Create an variable to store the structure from the decoded stucture
                let readableData = try jsonDecoder.decode(WeatherData.self, from: data)
                // Print the data in various formate
                
                print (readableData)
                print (readableData.name)
                print (readableData.main)
                
            }
            //Catch the Broken URL Decode
            catch {
                print ("Can't Decode")
                
            }
            
        }
        
    }
    dataTask.resume()// Resume the datatask method
    dataTask.response
}
